MICROLOGY STATIC REFERENCE HOUSE v1

This is a native cell-data fixture and inspection package, not a destruction replay.
Wall footprint: 6 x 5 m. Display scale annotation: 50 mm/cell.
Four materials: wood, masonry, concrete, glass proxy.
Glazing is an opaque, one-cell 50 mm proxy, not a resolved real pane.
No realistic mass, load capacity, finer debris or material tuning is claimed.

native-world/: original native world including separate underside anchors.
manifest.json: dimensions, material counts and structural checksum.
intact-preview.png / cutaway-preview.png: SOFTWARE renders of actual compiled
cell quads, not live Bevy/GPU screenshots. Cutaway is not simulated damage.
*-surfaces.json: the compiled surfaces used to render those images.
preview-provenance.json: source and image hashes.
verification.json: local command results and exact tested-source hashes.

Source branch: chatgpt/house-static-step6-20261003
Read docs/house-static-step6-checkpoint.md in the repository before demolition.
The package does not install anything, launch a program or overwrite any save.
Unpack to a NEW folder. Review these proportions before any destruction work.
