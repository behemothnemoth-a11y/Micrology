Micrology house window hit - Step 7
Evidence package, NOT a reloadable native save or video.
One headless impact; no physics time steps. Static-view hole excludes released pieces, which are listed completely in report.json.
Use house_window_bench in the Step 7 branch to reproduce.
See checkpoint.md for finite offline limits and remaining runtime blockers.
